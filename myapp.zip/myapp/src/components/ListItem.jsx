function ListItem({text}) {
    return (
        <>
        <li>{text}</li>
        </>
    )
}

export default ListItem