function Paragraph({text}) {
    return (
        <>
        <p>{text}</p>
        </>
    )
}

export default Paragraph