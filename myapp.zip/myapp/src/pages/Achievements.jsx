import Header from "../components/Header";
import Paragraph from "../components/Paragraph";

function Achievements(){
    return (
    <>
        <Header text={"Achievements"}></Header>
        <Paragraph text={"Testing"}></Paragraph>
    </>
    )
}

export default Achievements