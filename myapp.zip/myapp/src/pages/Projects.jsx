import Header from "../components/Header";
import Paragraph from "../components/Paragraph";

function Projects(){
    return (
    <>
        <Header text={"Projects"}></Header>
        <Paragraph text={"Testing this right now"}></Paragraph>   
    </>
    )
}

export default Projects