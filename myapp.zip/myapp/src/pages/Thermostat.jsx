import Header from "../components/Header";
import Paragraph from "../components/Paragraph";

function Thermostat(){
    return (
    <>
        <Header text={"Thermostat"}></Header>
        <Paragraph text={"Testing"}></Paragraph>
    </>
    )
}

export default Thermostat