import Header from "../components/Header";
import Paragraph from "../components/Paragraph";

function Home(){
    return (
    <>
        <Header text={"Home"}></Header>
        <Paragraph text={"Prajesh Raam H S - Student & Fullstack Developer"}></Paragraph>
        
    </>
    )
}

export default Home